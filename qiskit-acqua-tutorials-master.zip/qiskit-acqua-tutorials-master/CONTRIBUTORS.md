Contributors (listed alphabetically)
====================================

This work is the result of the efforts of many people. Many thanks to everyone
involved in the project:

- Panagiotis Barkoutsos
- Chun-Fu (Richard) Chen
- Antonio Córcoles-Gonzalez
- Jay Gambetta
- Jennifer Glick
- Tanvi Gujarati
- Shaohan Hu
- Takashi Imamichi
- Tal Kachman
- Peng Liu
- Manoel Marques
- Antonio Mezzacapo
- Nikolaj Moll
- Giacomo Nannicini
- Marco Pistoia
- Julia Rice
- Raymond Harry Putra Rudy
- Ivano Tavernelli
- Kristan Temme
- Stephen Wood
